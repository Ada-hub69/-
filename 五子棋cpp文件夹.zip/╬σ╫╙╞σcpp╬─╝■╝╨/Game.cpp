#include "Game.h"
#include <iostream>

Game::Game() : window(sf::VideoMode(BOARD_SIZE* CELL_SIZE + 2 * WINDOW_MARGIN, BOARD_SIZE* CELL_SIZE + 2 * WINDOW_MARGIN), "������"), currentPlayer(1), gameOver(false), winner(0) {
    // �������
    for (int i = 0; i < BOARD_SIZE; ++i)
        for (int j = 0; j < BOARD_SIZE; ++j)
            board[i][j] = 0;

    // �����������壨ȷ���� simhei.ttf��
    if (!font.loadFromFile("E:\source\repos\Gommoku\x64\Debug\simhei.ttf")) {
        std::cerr << "�޷��������� simhei.ttf" << std::endl;
    }

    statusText.setFont(font);
    statusText.setCharacterSize(30);
    statusText.setFillColor(sf::Color::Red);
    statusText.setPosition(50, 10);
    statusText.setString("�ڷ�����");
}

void Game::run() {
    while (window.isOpen()) {
        processEvents();
        update();
        render();
    }
}

void Game::processEvents() {
    sf::Event event;
    while (window.pollEvent(event)) {
        if (event.type == sf::Event::Closed)
            window.close();
        if (!gameOver && event.type == sf::Event::MouseButtonPressed) {
            if (event.mouseButton.button == sf::Mouse::Left) {
                handleClick(event.mouseButton.x, event.mouseButton.y);
            }
        }
    }
}

void Game::update() {
    if (gameOver) {
        if (winner == 1)
            statusText.setString("�ڷ�ʤ����");
        else if (winner == 2)
            statusText.setString("�׷�ʤ����");
    }
    else {
        statusText.setString(currentPlayer == 1 ? "�ڷ�����" : "�׷�����");
    }
}

void Game::render() {
    window.clear(sf::Color::White);

    // ������������
    for (int i = 0; i < BOARD_SIZE; ++i) {
        sf::Vertex hLine[] = {
            sf::Vertex(sf::Vector2f(WINDOW_MARGIN, WINDOW_MARGIN + i * CELL_SIZE), sf::Color::Black),
            sf::Vertex(sf::Vector2f(WINDOW_MARGIN + (BOARD_SIZE - 1) * CELL_SIZE, WINDOW_MARGIN + i * CELL_SIZE), sf::Color::Black)
        };
        sf::Vertex vLine[] = {
            sf::Vertex(sf::Vector2f(WINDOW_MARGIN + i * CELL_SIZE, WINDOW_MARGIN), sf::Color::Black),
            sf::Vertex(sf::Vector2f(WINDOW_MARGIN + i * CELL_SIZE, WINDOW_MARGIN + (BOARD_SIZE - 1) * CELL_SIZE), sf::Color::Black)
        };
        window.draw(hLine, 2, sf::Lines);
        window.draw(vLine, 2, sf::Lines);
    }

    // ��������
    for (int i = 0; i < BOARD_SIZE; ++i) {
        for (int j = 0; j < BOARD_SIZE; ++j) {
            if (board[i][j] != 0) {
                sf::CircleShape piece(CELL_SIZE / 2 - 2);
                piece.setPosition(WINDOW_MARGIN + j * CELL_SIZE - piece.getRadius(), WINDOW_MARGIN + i * CELL_SIZE - piece.getRadius());
                piece.setFillColor(board[i][j] == 1 ? sf::Color::Black : sf::Color::White);
                piece.setOutlineColor(sf::Color::Black);
                piece.setOutlineThickness(1);
                window.draw(piece);
            }
        }
    }

    window.draw(statusText);
    window.display();
}

void Game::handleClick(int x, int y) {
    int col = (x - WINDOW_MARGIN + CELL_SIZE / 2) / CELL_SIZE;
    int row = (y - WINDOW_MARGIN + CELL_SIZE / 2) / CELL_SIZE;

    if (row < 0 || row >= BOARD_SIZE || col < 0 || col >= BOARD_SIZE)
        return;
    if (board[row][col] != 0)
        return;

    board[row][col] = currentPlayer;

    if (checkWin(row, col, currentPlayer)) {
        gameOver = true;
        winner = currentPlayer;
    }
    else {
        currentPlayer = 3 - currentPlayer; // �л���ң�1->2��2->1��
    }
}

bool Game::checkWin(int row, int col, int player) {
    return countDirection(row, col, player, 1, 0) + countDirection(row, col, player, -1, 0) >= 4 ||  // ����
        countDirection(row, col, player, 0, 1) + countDirection(row, col, player, 0, -1) >= 4 ||  // ����
        countDirection(row, col, player, 1, 1) + countDirection(row, col, player, -1, -1) >= 4 || // б�� �K�I
        countDirection(row, col, player, 1, -1) + countDirection(row, col, player, -1, 1) >= 4;   // б�� �L�J
}

int Game::countDirection(int row, int col, int player, int dr, int dc) {
    int count = 0;
    for (int i = 1; i <= 4; ++i) {
        int r = row + dr * i;
        int c = col + dc * i;
        if (r < 0 || r >= BOARD_SIZE || c < 0 || c >= BOARD_SIZE) break;
        if (board[r][c] == player)
            count++;
        else
            break;
    }
    return count;
}

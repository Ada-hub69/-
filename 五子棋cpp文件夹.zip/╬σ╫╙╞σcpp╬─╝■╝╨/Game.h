#ifndef GAME_H
#define GAME_H

#include <SFML/Graphics.hpp>

const int BOARD_SIZE = 15;
const int CELL_SIZE = 40;
const int WINDOW_MARGIN = 50;

class Game {
public:
    Game();
    void run();

private:
    sf::RenderWindow window;
    sf::Font font;
    sf::Text statusText;

    int board[BOARD_SIZE][BOARD_SIZE];  // 0=�գ�1=���ӣ�2=����
    int currentPlayer;                  // 1=���ӣ�2=����
    bool gameOver;
    int winner;                         // 0=�ޣ�1=���ӣ�2=����

    void processEvents();
    void update();
    void render();
    void handleClick(int x, int y);
    bool checkWin(int row, int col, int player);
    int countDirection(int row, int col, int player, int dr, int dc);
};

#endif // GAME_H
